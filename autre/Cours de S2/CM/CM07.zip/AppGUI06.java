import javax.swing.*; // API pour les interfaces graphiques
import java.awt.event.*; // Pour les évènements
import java.awt.*;

/**
 * Classe permettant de capter un clic de souris.
 */
class EcouteurSouris extends MouseAdapter { // Utilisation d'un adaptateur
  public void mouseClicked(MouseEvent e) {
    int x = e.getX(); // Utilisation des informations relatives à l'évènement
    int y = e.getY();
    System.out.println("Coordonnées : (" + x + "," + y + ")");
  }
}

/**
 * Classe permettant de capter l'actionnement du bouton.
 * Il n'y a pas d'adaptateur, seulement un écouteur
 * car il n'y a qu'une méthode à implémenter.
 */
class EcouteurAction implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    System.out.println("Bouton pressé !");
  }
}

/**
 * Classe de panneau dans laquelle le dessin va se faire.
 */
class PanneauDessin extends JPanel {
  public void paintComponent(Graphics g) {
    super.paintComponent(g); // Dessin du JPanel
    // Trace une ligne de (15,10) à (115,210)
    g.drawLine(15, 10, 100, 200);
  }
}

class Fenetre extends JFrame { // Héritage
  public Fenetre() { // Constructeur
    this.setTitle("Ma première fenêtre graphique");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setBounds(100, 150, 200, 300); // Position x,y Taille l,h
    EcouteurSouris ecouteur = new EcouteurSouris(); // Création de l'écouteur
    // Attachement de l'écouteur à la fenêtre principale
    this.addMouseListener(ecouteur);

    Container c = this.getContentPane(); // Conteneur à alimenter

    // Gestionnaire de mise en forme
    // Inutile, c'est le gestionnaire par défaut
    BorderLayout gestionnaire = new BorderLayout();
    c.setLayout(gestionnaire);

    // Bouton et son texte
    JButton bouton = new JButton("OK");
    // Ecouteur pour capter l'actionnement
    EcouteurAction ecouteurBouton = new EcouteurAction();
    // Attachement au bouton
    bouton.addActionListener(ecouteurBouton);
    c.add(bouton,"South"); // On ajoute le bouton APRES le gestionnaire !

    // Panneau de dessin
    PanneauDessin dessin = new PanneauDessin();
    dessin.setBackground(Color.CYAN);
    c.add(dessin,"Center");
  }
}

public class AppGUI06 {
  public static void main(String[] args) {
    // Composants graphiques
    Fenetre cadrePrincipal = new Fenetre();
    cadrePrincipal.setVisible(true);
  }
}
