import javax.swing.*; // Pour les interfaces graphiques
public class AppGUI00 {
  public static void main(String[] args) {
    JFrame cadrePrincipal = new JFrame();

    // Possible avec le constructeur
    cadrePrincipal.setTitle("Ma première fenêtre graphique");

    cadrePrincipal.setSize(300, 150);
    cadrePrincipal.setVisible(true);
  }
}
