import javax.swing.*; // Pour les interfaces graphiques

class Fenetre extends JFrame { // Héritage
  public Fenetre() { // Constructeur
    this.setTitle("Ma première fenêtre graphique");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setBounds(100, 150, 200, 300); // Position x,y Taille l,h
  }
}

public class AppGUI01 {
  public static void main(String[] args) {
    Fenetre cadrePrincipal = new Fenetre();
    cadrePrincipal.setVisible(true);
    while (true) {
      System.out.println(cadrePrincipal.getSize());
    }
  }
}
