import javax.swing.*; // API pour les interfaces graphiques
import java.awt.event.*; // Pour les évènements

class EcouteurSouris implements MouseListener { // Classe d'écouteur de souris
  public void mousePressed(MouseEvent e) {
  }
  public void mouseReleased(MouseEvent e) {
  }
  public void mouseEntered(MouseEvent e) {
  }
  public void mouseExited(MouseEvent e) {
  }
  public void mouseClicked(MouseEvent e) {
    System.out.println("Clic Souris !");
  }
}

class Fenetre extends JFrame { // Héritage
  public Fenetre() { // Constructeur
    this.setTitle("Ma première fenêtre graphique");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setBounds(100, 150, 200, 300); // Position x,y Taille l,h
    EcouteurSouris ecouteur = new EcouteurSouris(); // Création de l'écouteur
    this.addMouseListener(ecouteur); // Attachement de l'écouteur à la fenêtre principale
  }
}

public class AppGUI02 {
  public static void main(String[] args) {
    Fenetre cadrePrincipal = new Fenetre();
    cadrePrincipal.setVisible(true);
  }
}
