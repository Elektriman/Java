/*
Visibilité des variables
*/

public class Visible {
  public static void main(String[] args) {
    int i; // 2. Enlever
    for (i=0; i<12; i++) { // 1. Ajouter int devant i
      System.out.println("Yep ! " + i);
    }
    System.out.println("Yop : " + i);
  }
}
