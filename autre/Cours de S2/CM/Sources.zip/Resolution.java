import java.util.Scanner;

public class Resolution {

  public static void main(String[] args) {
    // Entrées
    System.out.println("Programme de résolution de l'équation a x + b = 0.");
    Scanner s = new Scanner(System.in);
    System.out.print("Saisissez un nombre non-nul a : ");
    double a = s.nextDouble();
    System.out.print("Saisissez un nombre b : ");
    double b = s.nextDouble();
    // Calcul
    Double solutionNum;
    solutionNum = -b / a;
    // Sorties
    String solutionStr = solutionNum.toString();
    System.out.println("La solution est : " + solutionStr);
  }

// Et si, l'utilisateur donne 0 pour a ?
// Et si, l'utilisateur fait vraiment n'importe quoi ?
// Au CM2 : Transformation du code pour faire un sous-programme réutilisable.
// Pourquoi double et Double ?
}

/*
Compilation : javac <nom de la classe publique>.java
Exécution : java <nom de la classe contenant "main">
*/
