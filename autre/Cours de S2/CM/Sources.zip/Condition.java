import java.util.Scanner;

public class Condition {

  static final int VIEILLESSE = 30;

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    System.out.print("Quel est votre âge ? ");
    int n = s.nextInt();
    if (n > VIEILLESSE) {
      System.out.println("T'es foutu !");
    } else {
      System.out.println("Salut gamin !");
    }
  }
}

/*
1. Tester avec d'autres conditions ! || && ==, des conditions multiples
2. Imbriquer ou ne pas imbriquer ... là est la question.
*/
