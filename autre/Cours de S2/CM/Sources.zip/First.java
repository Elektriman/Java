/*
 Ceci est un bloc de commentaires.
*/

// Ceci est un commentaire sur une seule ligne.
/*
. Les commentaires : en bloc et sur une ligne
. Le premier programme, sa compilation, son exécution
. 
*/

/**
 * Ceci est un commentaire à destination de JavaDoc.
 * Il doit être utilisé pour expliquer à quoi sert CM1.
 */

public class First {
  // Point d'entrée obligatoire
  public static void main(String[] args) {
    // Pour le moment, c'est une boite noire. 
    // A la fin du semestre, vous aurez (presque) toutes les explications
    System.out.println("Premier CM de Java !"); 
    // Toutes les instructions se terminent pas un ;
  } // Tous les blocs sont entre accolades.
} // FIN !

// L'indentation n'est pas significative, mais toujours importante.
