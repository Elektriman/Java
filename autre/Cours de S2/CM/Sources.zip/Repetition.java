import java.util.Scanner;

public class Repetition {

  static final int nbIterations = 3;
  static final double erreur = 0.00001;

  public static void main(String[] args) {
    // Calcul de la somme de nombres entiers
    Scanner s = new Scanner(System.in);
    int n;
    long somme;
    somme = 0;
    for (int i = 0; i < nbIterations; i++) {
      System.out.print("Saisissez un entier ");
      n = s.nextInt();
      somme += n;
    }
    System.out.println("La somme des entiers saisis est : " + somme);

    // Algorithme de Héron
    System.out.print("Saisissez un nombre entier : ");
    long a = s.nextLong();
    double x = a;
    double next = (x + a/x)/2;
    while (Math.abs(x-next) > erreur) {
      x = next;
      next = (x + a/x)/2;
      System.out.println("Itération en cours : " + x);
    }
    System.out.println("Une valeur approchée de la racine carrée" +
                       " de votre nombre est : " + x); 
  }
}

/*
Ne pas oublier "do" 
*/
