import java.util.ArrayList;

public class Exemple01 {
  public static void main(String[] args) {
    ArrayList ens; // Déclaration d'un ArrayList
    ens = new ArrayList(); // Construction
    ens.add("Bonjour"); // Ajout d'une valeur dans ens
    ens.add(3); // Ajout d'une valeur dans ens
    double x = 12.5;
    ens.add(x); // Ajout d'une valeur dans ens

    System.out.println(ens.size()); // Quelle valeur est affichée ?
    System.out.println(ens.get(2)); // Quelle valeur est affichée ?
    ens.remove(1); // Quel élément est enlevé ?
    //Comment enlever le dernier élément ajouté ?
    System.out.println(ens.isEmpty()) ; // Quelle valeur est affichée ?
    // Comment afficher toutes les valeurs contenue dans ens ?
    // Attention : ens.get(0) = c ; est impossible
  }
}
