
import java.util.ArrayList;

class Etudiant {
    private String nom;
    private String prenom;
    private int age;
    private char genre;

    public Etudiant(String nom, String prenom, int age, char genre) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.genre = genre;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public int getAge() {
        return age;
    }

    public char getGenre() {
        return genre;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGenre(char genre) {
        this.genre = genre;
    }

    public String toString() {
        return this.getNom() + this.getPrenom() + ", age : "
                + this.getAge() + ", genre : " + this.getGenre();
    }
} // Fin de la classe Etudiant

/**
 *
 * @author jviaud
 */
public class Exemple02 {
    public static void main(String[] args) {
        ArrayList<Etudiant> classe = new ArrayList<Etudiant>();
        
        // Créer 3 étudiants et les placer dans cet ArrayList
        // Afficher le nom du premier étudiant
        // Afficher les nom de tous les étudiants
        // Calculer la proportion féminine
    }
}
