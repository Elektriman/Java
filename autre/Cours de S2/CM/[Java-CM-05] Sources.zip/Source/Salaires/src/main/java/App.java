import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author P. Rodriguez
 */
public class App {
   
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // Déclaration d'un lecteur de fichiers
        LecteurFichier monLecteur;
        // Création du lecteur
	monLecteur = new LecteurFichier() ; 	
        // Choix du fichier manipulé par le lecteur
	monLecteur.choisirFichier("revenus.txt") ;

        // Modifier en ArrayList
        ArrayList<Double> revenus; // Déclaration d'un arraylist pour récupérer les salaires.
	revenus = monLecteur.lectureReels(); // Lecture des noms dans le fichier et stockage dans le tableau
	System.out.println(revenus.size());
        
        ArrayList<Double> resultats = new ArrayList<Double>();
        resultats.add(1.0);
	EnregistreurFichier monEF; // Déclaration d'un Enregistreur de fichiers
	monEF = new EnregistreurFichier();
	monEF.choisirFichier("resultats.txt");
	monEF.enregistrerArrayList(resultats);
    }
}