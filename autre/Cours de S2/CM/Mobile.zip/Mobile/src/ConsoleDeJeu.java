
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

/**
 * @author P. Rodriguez
 * Fenetre->ConsoleDeJeu->ZoneDeJeu
 */
public class ConsoleDeJeu extends JPanel   {
    // ConsoleDeJeu hérite de la classe JPanel, 
    // Donc, tous les objets de la classe ConsoleDeJeu possèdent
    // les attributs et les méthodes de la classe JPanel
    // plus les attributs et méthodes définis ici
    
    // Attributs : La zone de jeu et la barre des boutons
    private final ZoneDeJeu maZoneDeJeu ;
    private final JMenuBar maBarreDeBoutons ;
    // Constantes
        // les mobiles se déplacent tous les 50ms 
    private final int PERIODE_DE_RAFFRAICHISSEMENT = 50 ; 
    
    // Constructeur
    public ConsoleDeJeu() {
        // Mettre en place un découpage en zones (nord, sud, est ouest, centre)
        this.setLayout(new BorderLayout());
        this.setFocusable(true);
        
        // Créer la barre des boutons et les boutons
        this.maBarreDeBoutons = creerBarreDeBoutons() ;
        
        // Placer la barre des boutons au sud 
        this.add(this.maBarreDeBoutons, BorderLayout.SOUTH); 
      
        // Détecte les événements liés à la souris et associe des actions à ces événements
        ajouterLesGestionnairesDEvenementSouris() ;
        
        // Détecte les événements liés au clavier et associe des actions à ces événements
        ajouterLesGestionnairesDEvenementClavier() ;
         
        // Créer le maZoneDeJeu de jeu
        maZoneDeJeu = new ZoneDeJeu() ;
        
        // Ajouter le maZoneDeJeu dans la game Boy, au centre
        this.add(maZoneDeJeu, BorderLayout.CENTER);
        
        // Ajouter des mobiles dans maZoneDeJeu
       Mobile m1 = new Mobile(1) ;
       maZoneDeJeu.ajouter(m1);
       
       maZoneDeJeu.ajouter(new Mobile(3));
        
        // Démarrer le jeu
        this.lancerLeJeu() ;
    }
  
    private void lancerLeJeu(){
        /* Création d'un thread
            permet de gérer plusieurs éléments séparément :
                - le déplacement des gluons
                - la gestion des événements lié à la souris ou au clavier
        */
        Thread threadDuJeu = new Thread() 
        {   
            @Override
            public void run(){ 
                /*********************************************/
                /**** Ceci est la boucle principale du jeu ***/
                /*********************************************/
                do{
                    //  System.out.println("Un tour de boucle principale");
                    // Ici, placer les instructions affectant les mobiles
                 
                    maZoneDeJeu.deplacerTousLesMobiles();
                    
                    repaint() ;// Trace tous les éléments 
                    try{ // Temporisation
                        Thread.sleep(PERIODE_DE_RAFFRAICHISSEMENT);
                    } catch(InterruptedException ex){
                    // A exécuter si une interruption intervient durant le sleep
                    }
                }while(true);
                // On peut choisir d'arrêter le jeu en plaçant une condition ici 
            }
        } ;// Fin de la création du thread
        threadDuJeu.start();// Lancement du thread
    }
    

    private  JMenuBar creerBarreDeBoutons(){
         // Création des menus
        JMenuBar leMenu = new JMenuBar() ;
          // Création des boutons
        JButton bouton1 = new JButton("Action 1") ;
        JButton bouton2 = new JButton("Action 2") ;
        JButton bouton3 = new JButton("Sélection ") ;
    
          // Ajout des boutons
        leMenu.add(bouton1) ;
        leMenu.add(bouton2) ;
        leMenu.add(bouton3) ;
        
        // Associons une action à  chaque bouton    
        
        bouton1.addActionListener((ActionEvent arg0) -> {
            System.out.println("Action 1 effectuée");
            maZoneDeJeu.getElementCourant().deplacer();
        });
        
         bouton2.addActionListener((ActionEvent arg0) -> {
             System.out.println("Action 2 effectuée");
            
        });
         
         bouton3.addActionListener((ActionEvent arg0) -> {
             System.out.println("Action 3 effectuée");
           
        });
             
        return leMenu ;
    }
   

    private void ajouterLesGestionnairesDEvenementSouris() {
         // Ajouter les gestionnaires d'évènement concernat la souris
        addMouseListener(new MouseAdapter(){
            @Override
            public void mousePressed(MouseEvent e){
                System.out.println("Clic : La souris est en "+e.getX()+", "+e.getY());
            }
        });
        
        addMouseMotionListener(new MouseAdapter(){
            @Override
            public void mouseMoved(MouseEvent e){
                System.out.println("Mouvement : La souris est en "+e.getX()+", "+e.getY());
            }
        });

        addMouseMotionListener(new MouseAdapter(){
            @Override
            public void mouseDragged(MouseEvent e){
                System.out.println("Drag : La souris est en "+e.getX()+", "+e.getY());
            }
        });
    }
    
    public void ajouterLesGestionnairesDEvenementClavier(){
        
      this.addKeyListener(new KeyListener() {  
        @Override
        public void keyTyped(KeyEvent e) {
            System.out.println("Touche tapée");
      } 
        
        @Override
         public void keyPressed(KeyEvent e) {
             System.out.println("Touche enfoncée : " + e.getKeyChar()+" "+e.getKeyCode());
             
         }
        @Override
          public void keyReleased(KeyEvent e) {
              System.out.println("Touche relachée");
          }
      });
       
    }
    
}
