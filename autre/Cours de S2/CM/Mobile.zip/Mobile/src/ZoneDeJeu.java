import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 * L'aire de jeu est le lieu graphique où se déplacent les éléments mobiles
 * @author P. Rodriguez
 */
public class ZoneDeJeu extends JPanel{
    
    // Attributs
        // Les mobiles présents dans l'aire de jeu
    private final ArrayList <Mobile> elements ;
        
    private int curseur ;// Le numéro du mobile "actif" :
        // (celui sur lequel le joueur peut agir)
    
    // Constantes de dimension
    private final int LARGEUR = 300 , HAUTEUR = 400 ;
    
// Constructeur
    public ZoneDeJeu() {
       // On construit l'arrayList pour le stockage des éléments du jeu
       this.elements = new ArrayList() ;
       // On sélectionne par défaut le premier element
       this.curseur = 0 ;
       this.setSize(LARGEUR, HAUTEUR);
    }
   
    public void deplacerTousLesMobiles(){
        for (int i = 0; i < this.elements.size(); i++) {
            this.elements.get(i).deplacer();
        }
       // System.out.println("Déplacement général");
    }
    
    // Permet de donner les dimensions de départ, 
        //redéfinition (override) de la méthode getPreferredSize de JPanel
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(LARGEUR,HAUTEUR);
    }
    
    // Définit comment seront tracés les composants graphiques de l'aire de jeu
    @Override
    public void paintComponent(Graphics gr) {
       for(int i = 0 ; i<this.elements.size(); i++){
           // Trace avec focus l'élément dont le numéro est dans this.curseur
           boolean focus = false ;
           if(i == this.curseur) focus = true ;
           this.elements.get(i).tracer(gr, focus);
          // System.out.println(this.elements.get(i));  
       } 
    }  

    /**
     * Ajoute un mobile dans la liste des mobiles
     * @param glu 
     */
    public void ajouter(Mobile glu) {
        this.elements.add(glu) ;
        // Sélectionner le dernier élément
        this.curseur = this.elements.size()-1 ;
    }
    
    /**
     * Renvoie le mobile sélectionné par le joueur
     * @return 
     */
    public Mobile getElementCourant(){
        return this.elements.get(this.curseur) ;
    }

    /**
     * Sélectionne le mobile suivant
     */
    void passerALElementSuivant() {
        this.curseur++ ;
        if(this.curseur>=this.elements.size())
           this.curseur = 0;    
    }
       
} // Fin de la classe