
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author P. Rodriguez
 */
public class Principale {
     public static void main(String[] args) {
        // Permet de confier une tache à l'Event Dispacher Thread
        // Considerez que l'EDT est un "programme" qui capte les événements 
        // (clic de souris, appui sur une touche du clavier ...),
        // et qui les confie aux gestionnaires d'événements
        
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                creerEtAfficherLaFenetre(); 
            }
        });
        
         Mobile m1, m2, m3;
         m1 = new Mobile(1,1,2,3,3,7); // Construction d'un objet
         m2 = new Mobile(1,1,2,3,3,7);
         
         //System.out.println(m1.getCategorie());
         m2.setCategorie(3); // Utilisation d'un setter pour modifier un attribut de l'objet m2
         
         //System.out.println(m1.getRayon());
         m1.grossir();
         //System.out.println(m1.getRayon());
         
         //System.out.println(m1);
                 //System.out.println(m2);
         
// Utilisation d'un getter pour récupérer la valeur d'un attribut
         //int tailleDeM1 = m1.getTaille();
         //int categorieDeM2 = m2.getCategorie();
         //System.out.println(m1.toString()); // Affichage
         //System.out.println(m1); // Affichage
     }

    private static void creerEtAfficherLaFenetre() {   
        Fenetre maFenetre = new Fenetre("Mon projet Java") ; 
    } 
    

    
}
