class Personne {
  private double poids;

  public Personne(double p) throws ExceptionPoids {
    if (p < 0.0) {
      // la levée d'exception fait sortir du sous-programme
      throw new ExceptionPoids();
    }
    this.poids = p;
  }
}

class ExceptionPoids extends Exception{
}

public class PersonnePoids {
  public static void main(String[] args) throws ExceptionPoids {
    //try {
      Personne Homer = new Personne(-5.0);
    //} catch (ExceptionPoids e) {
    //  System.out.println("Homer n'a pas un poids négatif");
    //}
    System.out.println("Fin du programme; Homer n'a pas été créé");
  }
}
