class Personne {

  private double poids;
  private int age;

  public Personne(double p, int a) throws ExceptionPoids, ExceptionAge {
    if (p < 0.0) {
      // la levée d'exception fait sortir du sous-programme
      throw new ExceptionPoids();
    }
    if (a > 1000) {
      throw new ExceptionAge();
    }
    this.poids = p;
    this.age = a;
  }
}

class ExceptionPoids extends Exception{
}

class ExceptionAge extends Exception{
}

public class PersonnePoidsAge01 {
  public static void main(String[] args) {
    try {
      Personne Homer = new Personne(200.0, 300);
    } catch (ExceptionPoids e) {
      System.out.println("Homer n'a pas un poids négatif");
    } catch (ExceptionAge e) {
      System.out.println("Personne n'est aussi vieux !");
    }
    System.out.println("Fin du programme; Homer n'a pas été créé");
  }
}
