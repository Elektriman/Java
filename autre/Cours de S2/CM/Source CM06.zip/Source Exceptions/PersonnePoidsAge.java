class Personne {
  private double poids;
  private int age;
  public Personne(double p, int a) throws ExceptionPersonne {
    if (p < 0.0) {
      // la levée d'exception fait sortir du sous-programme
      throw new ExceptionPersonne("Poids négatif");
    }
    if (a > 1000) {
      throw new ExceptionPersonne("Age supérieur à 1000");
    }
    this.poids = p;
    this.age = a;
  }
}

class ExceptionPersonne extends Exception{
  private String message; 
  public ExceptionPersonne(String m) {
    this.message = m;
  }

  public String getMessage() {
    return this.message;
  }
}

public class PersonnePoidsAge {
  public static void main(String[] args) {
    try {
      Personne Homer = new Personne(-200.0, 3000);
    } catch (ExceptionPersonne e) {
      System.out.println("La nature de l'exception est : " + e.getMessage());
    }
    
    System.out.println("Fin du programme; Homer n'a pas été créé");
  }
}
