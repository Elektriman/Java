class Personne {
  private double poids;
  private int age;
  public Personne(double p, int a) throws ExceptionPersonne {
    if (p < 0.0) {
      // la levée d'exception fait sortir du sous-programme
      throw new ExceptionPersonne("Poids négatif");
    }
    if (a > 1000) {
      throw new ExceptionPersonne("Age supérieur à 1000");
    }
    this.poids = p;
    this.age = a;
  }
}

class ExceptionPersonne extends Exception{
  private String message; 
  public ExceptionPersonne(String m) {
    this.message = m;
  }

  public String getMessage() {
    return this.message;
  }
}

class FabriquePersonne {
  public Personne creerPersonne(double p, int a) throws ExceptionPersonne {
    try {
      return new Personne(p, a);
    } finally {
      System.out.println("Avec ou sans exception");
      // Utile pour fermer un flux, en cas d'erreur sur un fichier.
      // Inutile si le "catch" est ici, il suffit de sortir du bloc.
    }
  }
}

public class PersonnePoidsAge03 {
  public static void main(String[] args) {
    try {
      FabriquePersonne f = new FabriquePersonne();
      Personne Homer = f.creerPersonne(-200.0,300);
    } catch (ExceptionPersonne e) {
      System.out.println("La nature de l'exception est : " + e.getMessage());
    }
    System.out.println("Fin du programme");
  }
}
