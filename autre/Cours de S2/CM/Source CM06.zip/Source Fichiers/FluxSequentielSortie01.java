import java.util.Scanner;
import java.io.*; // Pour les flux

public class FluxSequentielSortie01 {

  // L'écriture peut générer une exception
  public static void main(String[] args) throws IOException {

    Scanner s = new Scanner(System.in);

    // Les flux
    /*
     * Si le fichier n'existe pas, il est créée
     * S'il existe, il est écrasé
     */
    FileOutputStream f = new FileOutputStream("data.dat");

    // Liaison entre le flux de fichier et le flux de données
    DataOutputStream d = new DataOutputStream(f);

    int n;
    do {
      System.out.print("Saisissez un entier : ");
      n = s.nextInt();
      d.writeInt(n); // Ecriture dans le fichier via le flux de données
    } while (n != 0);
    d.close(); // Fermeture du flux
  }
}

/* Expérience : 
 * Tirer un million de nombres aléatoires et 
 * les écrire dans un fichier.
 * Version 1 : Sans Tampon (Buffer)
 * Version 2 : Avec Tampon
 */
