import java.io.*;

public class FluxTexteEntree04 {
  public static void main(String[] args) throws IOException {

  // Flux de texte
  FileReader f = new FileReader("data.txt"); // Flux fichier
  BufferedReader t = new BufferedReader(f); // Flux tampon de texte

  String l;
  do {
    l = t.readLine();
    if (l != null) {
      System.out.println("Ligne : " + l);
    }
  } while (l != null);
  t.close(); // Fermeture du flux
  }
}
