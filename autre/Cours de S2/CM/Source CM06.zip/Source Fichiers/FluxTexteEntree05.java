import java.io.*;
import java.util.StringTokenizer;

public class FluxTexteEntree05 {
  public static void main(String[] args) throws IOException {

  // Flux de texte
  FileReader f = new FileReader("data.txt"); // Flux fichier
  BufferedReader t = new BufferedReader(f); // Flux tampon de texte

  String l;
  do {
    l = t.readLine();
    if (l != null) {
      // Le caractère de séparation est l'espace
      StringTokenizer tokenizer = new StringTokenizer(l, " ");
      tokenizer.nextToken(); // On jette le mot "Entier"
      tokenizer.nextToken(); // On jette le mot ":"
      // On garde le prochain et on le convertit en entier
      String valeur = tokenizer.nextToken();
      Integer entier = new Integer(valeur);
      System.out.print(entier + " ");
    }
  } while (l != null);
  System.out.println("FIN");
  t.close(); // Fermeture du flux
  }
}
