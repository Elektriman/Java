import java.io.*; // Pour les flux

public class FluxSequentielEntree02 {
  // La lecture peut générer une exception
  public static void main(String[] args) throws IOException {

    // Les flux
    // Si le fichier n'existe pas, une exception est levée
    FileInputStream f = new FileInputStream("data.dat");
    // Liaison entre le flux de fichier et le flux de données
    DataInputStream d = new DataInputStream(f);

    boolean EOF = false; // EOF : End Of File
    int n = 0;
    while (!EOF) {
      try { // La détection de fin de fichier, se fait via une exception
        n = d.readInt();
      } catch (EOFException e) {
        EOF = true;
      }
      if (!EOF) {
        System.out.println(n);
      }
    }
  }
}

/* Remarque : 
 * L'encodage des entiers dans le fichier, dépend du langage.
 * Cela pose des problèmes d'interopérabilité.
 */
