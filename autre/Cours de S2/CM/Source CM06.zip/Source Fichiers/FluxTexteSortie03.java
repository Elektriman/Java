import java.io.*;
import java.util.Scanner;

public class FluxTexteSortie03 {
  public static void main(String[] args) throws IOException {
  Scanner s = new Scanner(System.in);
  int n;

  // Flux de texte
  /*
   * Si le fichier n'existe pas, il est créée
   * S'il existe, il est écrasé
   */
  FileWriter f = new FileWriter("data.txt"); // Flux fichier
  BufferedWriter tampon = new BufferedWriter(f); // Flux tampon
  PrintWriter p = new PrintWriter(tampon); // Flux texte formaté

  do {
    System.out.print("Saisissez un entier : ");
    n = s.nextInt();
    p.println("Entier : " + n + " ** "); // Ecriture
  } while (n != 0);
  p.close(); // Fermeture du flux
  }
}
