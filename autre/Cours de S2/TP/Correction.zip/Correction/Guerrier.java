class Guerrier
{
	// Attributs d'un Guerrier
	private String nom ;
	private int force ;
	private int sante ;
	private int experience ;
	private int age ;

	// Attribut commun � tous les Guerriers
	private static int nb = 0 ; // Nombre total de Guerriers cr��s
	
	// Constantes 
	private final static int forceMin = 1, forceMax = 5 ;
	private final static int santeMin = 0, santeMax = 100, limiteFaiblesse = 40 ;
	private final static int impactBlessure = -10 ; // Perte de sant� pour un combat perdu
	private final static int gainExperience = 1 ; // Gain d'exp�rience pour un combat remport� 
	private final static int experienceMin = 0, experienceMax = 10 ;
	private final static int ageMinDepart = 20, ageMaxDepart = 50 ;
	private final static int limiteJeunesse = 30, limiteVieillesse = 50 ;
	private final static int chanceMax = 10 ;
	private final static int DELTA_ETAT_RENF = 5,		// Un guerrier dont l'�tat de sant� s'am�liore gagne ce nombre d'unit�
				 DELTA_ETAT_AFFAIBL = -7;	// Un guerrier dont l'�tat de sant� se d�t�riore perd ce nombre d'unit�
	
	private static final double
		CHANCE_RENF_JEUNE_SAIN = 0.6 , 	// Un guerrier jeune et sain poss�de 60% de chance d'am�liorer son �tat
		CHANCE_RENF_JEUNE_FAIBLE = 0.5,
		CHANCE_RENF_ADULTE_SAIN = 0.7 ,
		CHANCE_RENF_ADULTE_FAIBLE = 0.6,
		CHANCE_RENF_VIEUX_SAIN = 0.4 ,
		CHANCE_RENF_VIEUX_FAIBLE = 0.2;

	// Constructeurs
	
	Guerrier() // Constructeur sans param�tres, cr�e un guerrier n�nb+1
	{
		nb++ ;
		this.nom = "n�"+nb ;
		this.force = entierAleatoire(forceMin,forceMax);
		this.sante = entierAleatoire(limiteFaiblesse,santeMax);
		this.age = entierAleatoire(ageMinDepart,ageMaxDepart);
		this.experience = experienceMin ; 
	}
	
	Guerrier(String leNom)
	{
		this() ; // Appel au constructeur sans param�tre
		this.nom = leNom ;
	}
	
	/************ M�thodes **************/
	
	// Getteurs	de niveau 1
	public int getExperience(){ return this.experience ; }
	public int getForce(){ return this.force ; }
	
	
	// Getteurs de niveau 2
	public boolean estFaible(){ return this.sante<limiteFaiblesse ;}
	public boolean estMort(){ return this.sante<santeMin ;}
	public boolean estVivant(){ return !this.estMort() ;}
	public boolean estJeune(){ return this.age<limiteJeunesse ;}
	public boolean estVieux(){ return this.age>limiteVieillesse ;}
	public boolean estAdulte(){ return !this.estJeune() && !this.estVieux() ; }
	public double vigueur() { 
	  if (this.estVivant())
	    return this.experience*(experienceMax-experienceMin)/(forceMax-forceMin)+this.force ;
	  else return 0 ;
	}

	// Setteurs de niveau 1
	public void modifierExperience(int bonus){ 
	  this.experience += bonus ; 
	  if ( this.experience>experienceMax) 
	    this.experience = experienceMax;
	} 
	public void modifierSante(int bonus){ 
	  this.sante += bonus ; 
	  if ( this.sante>santeMax) 
	    this.sante = santeMax;
	}
 
	// Setteurs de niveau 2
	public void vieillir(){
	  if(this.estVivant()){
	    this.age++ ; this.evoluer() ;
	  }
	}

	public void combattre(Guerrier adversaire)
	{
		// L'issue du combat d�pend de la diff�rence de force et d'exp�rience des combattants et d'une dose d'al�atoire
		// Chaque combat gagn� augmente l'exp�rience
		// Chaque combat perdu diminue l'�tat de sant�
		int delta_exp = this.experience - adversaire.getExperience() ;
		int delta_force = this.force - adversaire.getForce() ;
		int delta_alea = entierAleatoire(-chanceMax, chanceMax) ;
		int resultatCombat = delta_exp + delta_force + delta_alea ;
		Guerrier perdant = this , gagnant = adversaire;
		if(resultatCombat>0)	{ perdant = adversaire ;	gagnant = this ;	}
		gagnant.modifierExperience(gainExperience) ;
		perdant.modifierSante(impactBlessure) ;
	}
	
	
	
	
	/*********** Pr�paration � l'affichage  : m�thode toString ******************/
	public String toString() {
	  String s = this.nom + " (" + this.age + " ans, force : " + 
		     this.force +  ", sant� : "+ this.sante +  ", exp�rience : "+ this.experience + ") ";
	  return s ;
	}
	
	public char affichage()
	{	char representation = '|' ;
		if(this.estMort()) representation='-' ;
		else if(this.estFaible()) representation='/' ;
		return representation ;
	}
	
	public void evoluer() {
	  int delta = 0 ;
	  if(this.estJeune()) {
	    if(!this.estFaible()) {
		if(chance(CHANCE_RENF_JEUNE_SAIN)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL;
	    } else {
		if(chance(CHANCE_RENF_JEUNE_FAIBLE)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
	    }
	  }
	  if(this.estAdulte()) {
	    if(!this.estFaible()) {
		if(chance(CHANCE_RENF_ADULTE_SAIN)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
	    } else { 
		if(chance(CHANCE_RENF_ADULTE_FAIBLE)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
	    }
	  }
	  if(this.estVieux()) {
	    if(!this.estFaible()) {
		if(chance(CHANCE_RENF_VIEUX_SAIN)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
	    } else {
	    if(chance(CHANCE_RENF_VIEUX_FAIBLE)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
	    }
	  }
	  this.modifierSante(delta) ;
	}
	
	
	/************ Outils locaux (private) **********************/
	private static boolean chance(double x) { return Math.random()<x ; }
	
	private int entierAleatoire(int min, int max){ return (int)(min+(max+1-min)*Math.random()) ;}

}
