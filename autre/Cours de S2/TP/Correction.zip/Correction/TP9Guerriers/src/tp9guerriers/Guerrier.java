/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp9guerriers;

/**
 *
 * @author P. Rodriguez
 */
public class Guerrier {
// Attributs d'un Guerrier
	private String nom ;
	private int force ;
	private int sante ;
	private int experience ;
	private int age ;

	
	// Attribut commun à tous les Guerriers
	private static int nb = 0 ; // Nombre total de Guerriers créés
	
	
	// Constantes 
	private final static int    FORCE_MIN = 1, FORCE_MAX = 5 ,
                                    SANTE_MIN = 0, SANTE_MAX = 100, LIMITE_FAIBLESSE = 40 ,
                                    IMPACT_BLESSURE = -10 , // Perte de santé pour un combat perdu
                                    GAIN_EXPERIENCE = 1 , // Gain d'expérience pour un combat remporté 
                                    EXPERIENCE_MIN = 0, EXPERIENCE_MAX = 10 ,
                                    AGE_MIN_DEPART = 20, AGE_MAX_DEPART = 50 ,
                                    LIMITE_JEUNESSE = 30, LIMITE_VIEILLESSE = 50 ,
                                    CHANCE_MAX = 10 ,
                                    DELTA_ETAT_RENF = 5,	// Un guerrier dont l'état de santé s'améliore gagne ce nombre d'unité
                                    DELTA_ETAT_AFFAIBL = -7	;// Un guerrier dont l'état de santé se détériore perd ce nombre d'unité								 DELTA_ETAT_AFFAIBL = -7	;		// Un guerrier dont l'état de santé se détériore perd ce nombre d'unité
		  
	
	private static final double
		CHANCE_RENF_JEUNE_SAIN = 0.6 , 	// Un guerrier jeune et sain possède 60% de chance d'améliorer son état
		CHANCE_RENF_JEUNE_FAIBLE = 0.5,
		CHANCE_RENF_ADULTE_SAIN = 0.7 ,
		CHANCE_RENF_ADULTE_FAIBLE = 0.6,
		CHANCE_RENF_VIEUX_SAIN = 0.4 ,
		CHANCE_RENF_VIEUX_FAIBLE = 0.2				 
				;

	
	
	// Constructeurs
	
	Guerrier() // Constructeur sans paramètres, crée un guerrier n°nb+1
	{
		nb++ ;
		this.nom = "n°"+nb ;
		this.force = entierAleatoire(FORCE_MIN,FORCE_MAX);
		this.sante = entierAleatoire(LIMITE_FAIBLESSE,SANTE_MAX);
		this.age = entierAleatoire(AGE_MIN_DEPART,AGE_MAX_DEPART);
		this.experience = EXPERIENCE_MIN ; 
	}
	
	Guerrier(String leNom)
	{
		this() ; // Appel au constructeur sans paramètre
		this.nom = leNom ;
	}
	
	/************ Méthodes **************/
	
	// Getteurs	de niveau 1
	public int getExperience(){ return this.experience ; }
	public int getForce(){ return this.force ; }
	
	
	// Getteurs de niveau 2
	public boolean estFaible(){ return this.sante<LIMITE_FAIBLESSE ;}
	public boolean estMort(){ return this.sante<SANTE_MIN ;}
	public boolean estVivant(){ return !this.estMort() ;}
	public boolean estJeune(){ return this.age<LIMITE_JEUNESSE ;}
	public boolean estVieux(){ return this.age>LIMITE_VIEILLESSE ;}
	public boolean estAdulte(){ return !this.estJeune() && !this.estVieux() ; }
	public double vigueur()
	{ 
		if (this.estVivant())
			return this.experience*(EXPERIENCE_MAX-EXPERIENCE_MIN)/(FORCE_MAX-FORCE_MIN)+this.force ;
	 	else return 0 ;
	}
	// Setteurs de niveau 1
	public void modifierExperience(int bonus){ this.experience += bonus ; if ( this.experience>EXPERIENCE_MAX) this.experience = EXPERIENCE_MAX ; } 
	public void modifierSante(int bonus){ this.sante += bonus ; if ( this.sante>SANTE_MAX) this.sante = SANTE_MAX ; } 
	// Setteurs de niveau 2
	public void vieillir(){if(this.estVivant()){this.age++ ; this.evoluer() ;}}
	
	public void combattre(Guerrier adversaire)
	{
		// L'issue du combat dépend de la différence de force et d'expérience des combattants et d'une dose d'aléatoire
		// Chaque combat gagné augmente l'expérience
		// Chaque combat perdu diminue l'état de santé
		int delta_exp = this.experience - adversaire.getExperience() ;
		int delta_force = this.force - adversaire.getForce() ;
		int delta_alea = entierAleatoire(-CHANCE_MAX, CHANCE_MAX) ;
		int resultatCombat = delta_exp + delta_force + delta_alea ;
		Guerrier perdant = this , gagnant = adversaire;
		if(resultatCombat>0)	{ perdant = adversaire ;	gagnant = this ;	}
		gagnant.modifierExperience(GAIN_EXPERIENCE) ;
		perdant.modifierSante(IMPACT_BLESSURE) ;
	}
	
	
	
	
	// Autres
        @Override
	public String toString()
	{
		String s = this.nom + " (" + this.age + " ans, force : "+ this.force +  ", santé : "+ this.sante +  ", expérience : "+ this.experience + ") ";
		return s ;
	}
	
	public char affichage()
	{	char representation = '|' ;
		if(this.estMort()) representation='-' ;
		else if(this.estFaible()) representation='/' ;
		return representation ;
	}
	
	public void evoluer()
	{
		int delta = 0 ;
		if(this.estJeune())
			if(!this.estFaible())
				if(chance(CHANCE_RENF_JEUNE_SAIN)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
			else 
				if(chance(CHANCE_RENF_JEUNE_FAIBLE)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
		
		if(this.estAdulte())
			if(!this.estFaible())
				if(chance(CHANCE_RENF_ADULTE_SAIN)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
			else 
				if(chance(CHANCE_RENF_ADULTE_FAIBLE)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;				

		if(this.estVieux())
			if(!this.estFaible())
				if(chance(CHANCE_RENF_VIEUX_SAIN)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;
			else 
				if(chance(CHANCE_RENF_VIEUX_FAIBLE)) delta = DELTA_ETAT_RENF; else delta= DELTA_ETAT_AFFAIBL ;					
	
		this.modifierSante(delta) ;
	}
	
	
	/*********** Préparation à l'affichage  : méthode toString ******************/
	
	
	
		
	/************ Outils locaux (private) **********************/
	private static boolean chance(double x) {		return Math.random()<x ;	}
	
	private int entierAleatoire(int min, int max){ return (int)(min+(max+1-min)*Math.random()) ;}
	
	
    
}
