/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp9guerriers;

/**
 *
 * @author P. Rodriguez
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
	{
		Guerrier p1 = new Guerrier() ;
		System.out.println(p1) ;
		Guerrier p2 = new Guerrier("Ruth") ;
		while(p2.estVivant()) 
		{
			p2.vieillir() ;
			System.out.println(p2) ;
		}
	/*
		while(!p1.estMort() && !p2.estMort())
		{
			p1.combattre(p2) ;
			System.out.println(p1) ;
			System.out.println(p2) ;
			System.out.println() ;
		}*/
	/*	Clan c1 = new Clan("Huns") ;
		c1.ajouter(p1) ;
		c1.ajouter(p2) ;
		c1.modifierSante(-40) ;
		System.out.println(c1) ;
		Clan c2 = c1.elementsVigoureux() ;
		System.out.println(c2) ;
	*/
	Clan c1=new Clan (10) ;
	Clan c2=new Clan (15) ;
	
	while(!c1.estDecime() && ! c2.estDecime())
	{
		c1.combattre(c2) ;
		c1.nettoyer() ;
		c2.nettoyer() ;
		System.out.println(c1.affichage()+" vs "+c2.affichage()) ;	
	}
	/*int ageClan = 0 ;
	while(!c1.estDecime())
	{
		System.out.println(c1.affichage()) ;
		c1.vieillir() ;
		ageClan++ ;
	}
	System.out.println("Durée du clan : "+ageClan) ;
	*/
	}

    
}
