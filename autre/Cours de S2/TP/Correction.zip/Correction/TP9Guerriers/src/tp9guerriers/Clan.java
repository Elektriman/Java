/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp9guerriers;

import java.util.ArrayList;

/**
 *
 * @author P. Rodriguez
 */
public class Clan {
   // Attributs
	private ArrayList <Guerrier> elements ;
	private String nom ;
	
	// Constructeur
	Clan(){ this.elements = new ArrayList() ; this.nom = "Anonyme" ;} 
	Clan(String leNom){ this() ; this.nom = leNom ;}
	Clan(int nbG)
	{  this() ;
		for(int i = 0 ; i< nbG ; i++) this.ajouter(new Guerrier()) ;
	}	
	
	// Getteurs
	public int nombreGuerriers(){ return this.elements.size() ;}
	
	public boolean estDecime()
	{
		boolean r = true ;
		for(Guerrier p : this.elements) r &= p.estMort() ;
		return r ;
	}
	
	public Guerrier getNieme(int i){ return this.elements.get(i) ;}
	
	public Clan elementsVigoureux()
	{
		Clan v = new Clan("Eléments vigoureux du clan "+ this.nom) ;
		for(Guerrier p : this.elements)
			if(!p.estFaible()) v.ajouter(p) ;
		return v ;
	}
	
	// Setteurs
	public void ajouter(Guerrier p){ this.elements.add(p) ; }
	public void vieillir(){ this.elements.forEach((p) -> {
            p.vieillir() ;
            });
}
	public void modifierSante(int bonus){for(Guerrier p : this.elements) p.modifierSante(bonus) ;}

	// Autres
	public void nettoyer()
	{
		Clan aux = new Clan() ;
		for(Guerrier p : this.elements) if(p.estVivant()) aux.ajouter(p) ;
		this.elements = aux.elements ;	
	}
	
	public Guerrier lePlusVigoureux()
	{
		Guerrier gMax = this.elements.get(0) ;
		for(Guerrier g : this.elements)
			if(g.vigueur()>gMax.vigueur()) gMax = g ;
		return gMax ;
	}
	
	public void trierParVigueur()
	{
		Clan aux = new Clan() ;
		while(!this.elements.isEmpty())
		{
			Guerrier g = this.lePlusVigoureux() ;
			this.elements.remove(g) ;
			aux.ajouter(g) ;
		}
		this.elements = aux.elements ;
	}
	
	public Guerrier niemePlusVigoureux(int n)
	{
		this.trierParVigueur();
		return this.elements.get(n-1) ;
	}
	
	public void combattre(Clan adversaire)
	{
		// Faire se battre un guerrier de this et un guerrier des adversaires
		Clan plusNombreux, moinsNombreux ;
		if(this.nombreGuerriers()>adversaire.nombreGuerriers()){ plusNombreux = this ; moinsNombreux = adversaire ;}
		else 		{ plusNombreux = adversaire ; moinsNombreux = this ;}

		for(int i = 0; i< moinsNombreux.nombreGuerriers() ; i++)
		{
			moinsNombreux.getNieme(i).combattre(plusNombreux.getNieme(entierAleatoire(0,plusNombreux.nombreGuerriers()-1))) ;
		
		}
	/*	
		this.getNieme(
			entierAleatoire(0,this.nombreGuerriers()-1)
				)
			.combattre(
				adversaire.getNieme(
					entierAleatoire(0,this.nombreGuerriers()-1)
					)
				) ;		
				*/
	}
	
	/*
	public void combattre(Clan adversaire)
	{
		// Faire se battre tous les guerriers du clan le moins nombreux avec les plus vigoureux du clan le plus nombreux
		Clan plusNombreux, moinsNombreux ;
		if(this.nombreGuerriers()>adversaire.nombreGuerriers()){ plusNombreux = this ; moinsNombreux = adversaire ;}
		else 		{ plusNombreux = adversaire ; moinsNombreux = this ;}
		for(int i = 0 ; i<moinsNombreux.nombreGuerriers(); i++)
		{
			moinsNombreux.niemeGuerrier(i).combattre(plusNombreux.niemePlusVigoureux(i+1)) ;	
		}
		
	}
	*/
	public String affichage()
	{
		String s ="" ;
		for(Guerrier p : this.elements) s+=p.affichage() ;
		return s ;
	}
	public String toString()
	{
		String s = this.nom + ", "+ this.elements.size()+" gerriers : \n";
		for(Guerrier p : this.elements) s+= "\t"+ p +"\n";
		if(this.estDecime()) s += "Ce clan est décimé ! \n" ;
		return s ;
	}
	
	private int entierAleatoire(int min, int max){ return (int)(min+(max+1-min)*Math.random()) ;}
 
}
