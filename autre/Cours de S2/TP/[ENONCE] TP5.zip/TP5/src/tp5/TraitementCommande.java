
package tp5;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author P. Rodriguez
 */
public class TraitementCommande {

    private ArrayList<LigneDeCommande> lesLignesCommande;
    
    
    public TraitementCommande() {
       try{ 
        this.lesLignesCommande = lectureFichier("lignesDeCommande.txt") ;
       } catch(IOException e){ 
           System.out.println("ERREUR CHARGEMENT"); 
       }
    }

	
	public ArrayList<LigneDeCommande> lectureFichier(String nomFichier) throws IOException
	{
		ArrayList<LigneDeCommande> resultat ;
		resultat = new ArrayList() ;
		
		FileReader fr = new FileReader(nomFichier) ;
		
		LigneDeCommande li = new LigneDeCommande() ;
		while(li.lireDansFichier(fr))
		{
				resultat.add(li) ;
				li = new LigneDeCommande() ;	
		}
		return resultat ;
	}
    
}
