
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class App {
    public static void main(String[] args) {
        MaisonHantee m = new MaisonHantee();
        Scanner sc = new Scanner(System.in);
        String orgue;
        String encens;
        int compteur = 0;
        while (compteur != 2) {
            System.out.println("Etat de la maison: " + m);
            System.out.print("Jouez-vous de l'orgue aujourd'hui ? [O|N] : ");
            orgue = sc.next();
            System.out.print("Faites-vous bruler de l'encens "
                    + "aujourd'hui ? [O|N] : ");
            encens = sc.next();
            m.changeJour(encens.equals("O"), orgue.equals("O"));
            if (m.silence()) {
                System.out.println("Merci !");
                compteur++;
            }
        }
        System.out.println("Un silence durable règne ...");
    }
}
