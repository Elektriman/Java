/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class MaisonHantee {
    private boolean rire;
    private boolean chant;

    public MaisonHantee() {
        rire = true;
        chant = true;
    }

    public boolean silence() {
        return !rire && !chant;
    }

    public void changeJour(boolean encens, boolean orgue) {
        boolean oldRire = rire;
        boolean oldChant = chant;
        if (encens) {
            rire = oldChant;
        } else {
            rire = !oldChant;
        }
        if (orgue && !oldRire) {
            chant = !oldChant;
        }
    }

    public String toString() {
        String s = "[";
        if (rire) {
            s += "Rire";
        }
        if (chant) {
            s += "Chant";
        }
        s += "]";
        return s;
    }
}
