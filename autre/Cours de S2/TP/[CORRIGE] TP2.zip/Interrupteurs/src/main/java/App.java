
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class App {
    public static void main(String[] args) {
        Panneau jeu = new Panneau();
        Scanner sc = new Scanner(System.in);
        int numero; // Numero de l'interrupteur à actionner.
        while (!jeu.allumees()) {
            System.out.println("Etat du panneau : " + jeu);
            System.out.print("Interrupteur à actionner : ");
            numero = sc.nextInt();
            switch (numero) {
                case 1 : jeu.interrupteur1();
                break;
                case 2 : jeu.interrupteur2();
                break;
                case 3 : jeu.interrupteur3();
                break;
                case 4 : jeu.interrupteur4();
                break;
                case 5 : jeu.interrupteur5();
                break;
            }
        }
        System.out.println("Gagné !");
    }
}
