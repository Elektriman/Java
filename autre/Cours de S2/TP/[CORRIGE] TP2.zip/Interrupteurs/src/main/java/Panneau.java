/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class Panneau {
    private boolean lumiere1;
    private boolean lumiere2;
    private boolean lumiere3;
    private boolean lumiere4;
    private boolean lumiere5;

    /**
     * Constructeur initialisant les lumières de manières aléatoire.
     */
    public Panneau() {
        lumiere1 = (Math.random() > 0.5);
        lumiere2 = (Math.random() > 0.5);
        lumiere3 = (Math.random() > 0.5);
        lumiere4 = (Math.random() > 0.5);
        lumiere5 = (Math.random() > 0.5);
    }

    /**
     * Getter de fin de jeu.
     * Toutes les lumières sont allumées.
     */
    public boolean allumees() {
        return lumiere1 && lumiere2 && lumiere3 && lumiere4 && lumiere5;
    }

    /**
     * Setteur de l'interrupteur 1 qui agit sur la lumière 2.
     */
    public void interrupteur1() {
        lumiere2 = !lumiere2;
    }

    /**
     * Setteur de l'interrupteur 2 qui agit sur les lumières 2 et 3.
     */
    public void interrupteur2() {
        lumiere2 = !lumiere2;
        lumiere3 = !lumiere3;
    }

    /**
     * Setteur de l'interrupteur 3 qui agit sur les lumières 3 et 4.
     */
    public void interrupteur3() {
        lumiere3 = !lumiere3;
        lumiere4 = !lumiere4;
    }

    /**
     * Setteur de l'interrupteur 4 qui agit sur les lumières 4 et 5.
     */
    public void interrupteur4() {
        lumiere4 = !lumiere4;
        lumiere5 = !lumiere5;
    }

    /**
     * Setteur de l'interrupteur 5 qui agit sur les lumières 1 et 5.
     */
    public void interrupteur5() {
        lumiere1 = !lumiere1;
        lumiere5 = !lumiere5;
    }

    /**
     * Version chaine du panneau.
     * Convention : X pour ON, O pour OFF.
     *
     * @return Version chaine du panneau
     */
    @Override // Facultatif. Héritage pas abordé. Ne pas confondre avec overload
    public String toString() {
        String s = "[";
        if (this.lumiere1) {
            s += "X";
        } else {
            s += "O";
        }
        if (this.lumiere2) {
            s += "X";
        } else {
            s += "O";
        }
        if (this.lumiere3) {
            s += "X";
        } else {
            s += "O";
        }
        if (this.lumiere4) {
            s += "X";
        } else {
            s += "O";
        }
        if (this.lumiere5) {
            s += "X";
        } else {
            s += "O";
        }
        s += "]";
        return s;
    }
}

/*
 * En termes de modélisation et de duplication de code,
 * il y a évidemment beaucoup à revoir.
 * A transmettre à Armelle pour le génie logiciel :-)
 */
