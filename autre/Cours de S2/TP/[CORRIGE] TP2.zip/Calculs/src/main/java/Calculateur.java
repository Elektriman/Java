
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class Calculateur {
    public Calculateur() {
    }

    public void moyenne() {
        Scanner sc = new Scanner(System.in);
        double moyenne = 0.0;
        int nbInvalides = 0;
        for (int i = 0; i < 10; i++) {
            System.out.print("Saisissez une note : ");
            double note = sc.nextDouble();
            if (note > 20 || note < 0) {
                System.out.println("Note invalide");
                nbInvalides++;
            } else {
                moyenne = ( (i - nbInvalides) * moyenne + note)
                        / (i + 1 - nbInvalides);
                System.out.println("Jusqu'à maintenant la moyenne est de : "
                        + moyenne);
            }
        }
    }

    public double moyenne(int n) {
        Scanner sc = new Scanner(System.in);
        double moyenne = 0.0;
        int compteur = 0;
        while (compteur < n) {
            double note = sc.nextDouble();
            if (note <= 20 && note >= 0) {
                moyenne = (compteur * moyenne + note) / (compteur + 1);
                compteur++;
            }
        }
        return moyenne;
    }

    public double moyenneV2() {
        Scanner sc = new Scanner(System.in);
        double moyenne = 0.0;
        int compteur = 0;
        double note;
        do {
            note = sc.nextDouble();
            if (note <= 20 && note >= 0) {
                moyenne = (compteur * moyenne + note) / (compteur + 1);
                compteur++;
            }
        } while (note != -1.0);
        return moyenne;
    }
}
