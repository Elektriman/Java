/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class App {
    public static void main(String[] args) {
        Calculateur calc = new Calculateur();
        //calc.moyenne();
        //System.out.println("La moyenne est : " + calc.moyenne(3));
        System.out.println(calc.moyenneV2());
    }
}
