/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeu;

import java.util.Scanner;

/**
 *
 * @author Jean-François
 */
public class Jeu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double hasard = Math.random(); // Nombre aléatoire entre 0 et 1.
        int surprise = (int) (100*hasard); // Conversion d'un double en entier.
        Scanner sc = new Scanner(System.in);
        int nbUser;
        do {
            System.out.print("Saisissez un nombre entier entre 0 et 100 : ");
            nbUser = sc.nextInt();
            if (nbUser > surprise) {
                System.out.println("Plus Petit !");
            } 
            if (nbUser < surprise) {
                System.out.println("Plus Grand !");
            }
        } while (nbUser != surprise);
        System.out.println("Gagné !");
    }   
}