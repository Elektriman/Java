import java.util.Scanner ; 

/*
. Sous-programme "afficherDiviseurs"
. Sous-programme "listeDiviseurs"
. Sous-programme "nbDiviseurs"
. Sous-programme "estPremier"
. Sous-programme "decompositionFacteursPremiers"
. Sous-programme "nbDiviseurs2"
*/

class Exercice03
{

	public static void main(String[] args)
	{
		afficherDiviseurs(2100) ;
		System.out.println("\nNombre de diviseurs : " + nbDiviseurs(2100)) ;
		System.out.println(listeDiviseurs(2100));
		System.out.println(estPremier(2100));
		System.out.println(decompositionFacteursPremiers(2100)) ;
		System.out.println(nbDiviseurs2(2100)) ;

	}

	// Question 1
	public static void afficherDiviseurs(int n) 
	{
		for(int i = 1 ; i<n+1; i++)
			if(n%i == 0) System.out.print(i+" ") ;
	}

	// Question 2
	public static String listeDiviseurs(int n) 
	{
		String s = "";
		for(int i = 1 ; i<n+1; i++)
			if(n%i == 0) s = s + i + " " ;
		return s;
	}

	// Question 3
	public static int nbDiviseurs(int n) 
	{
		int resultat = 0 ;
		for(int i = 1 ; i<n+1; i++)
			if(n%i == 0) resultat++ ;
		return resultat ;
	}

	// Question 4
	public static boolean estPremier(int n)
	{
		if (nbDiviseurs(n)==2) {
			return true ;
		} else {
			return false ;
		}
		// ou return (nbDiviseurs(n)==2);
	}

	// Question 5
	public static String decompositionFacteursPremiers(int n)
	{
		String resultat = "";
		if (n == 1) {
			resultat = "1";
		} else {
			int div = 2; // diviseur premier à tester
			int puissance = 0;
			int reste = n; // ce qui reste à décomposer
			while (reste != 1) {
				if (reste%div == 0) {
					/* Encore diviseur.
					 * Il suffit d'augmenter la puissance.
					 * Et diviser le reste
					 */
					puissance = puissance + 1;
					reste = reste / div;
				} else { // Ce n'est plus diviseur
					if (puissance!=0) {
						// Mise à jour du résultat si nécessaire
						resultat = resultat + div + "^" + puissance + "x";
					}
					div++; // On va cherche le prochain premier
					while (!estPremier(div)) {
						div++;
					}
					puissance = 0; // On réinitialise
				}
			}
			// Ajout du dernier diviseur
			resultat = resultat + div + "^" + puissance;
		}
		return resultat;
	}

	// Question 6
	public static int nbDiviseurs2(int n) {
		String decomp = decompositionFacteursPremiers(n);
		String[] termes = decomp.split("x");
		int nbDiv = 1;
		for (int i = 0; i < termes.length; i++) {
			/* Version String de l'exposant
			 * ^ est spécial, il faut l'échapper avec \\
			 * puis l'exposant se trouve en seconde position. */
			String exp = termes[i].split("\\^")[1];
			// Conversion en int
			// puis puissance augmentée de 1
			nbDiv = nbDiv * (Integer.parseInt(exp) + 1);
		}
		return nbDiv;
	} // Il reste au moins un cas où ça ne marche pas :-)
}
