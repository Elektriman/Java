import java.util.Scanner;

public class SystemeImperial {
  // Déclaration des constantes
  private static final double LIVRE = 2.20462;
  private static final double ONCE = 35.2739199982575;

  // Les fonctions de conversion
  public static double conversionKilogrammeVersLivre(double kilogramme) {
    return kilogramme*LIVRE;
  }

  public static double conversionKilogrammeVersOnce(double kilogramme) {
    return kilogramme*ONCE;
  }

  // ---------- MAIN -------------
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    //System.out.print("Entrez un "double" : ");
    double x = sc.nextDouble();
    // Changements de type et arrondis
    long lbs = (long) Math.floor(conversionKilogrammeVersLivre(x));
    long oz = (long) Math.floor(conversionKilogrammeVersOnce(x-lbs/LIVRE));
    String s = lbs + "lbs " + oz + "oz";
    System.out.println(s);
  }
}
