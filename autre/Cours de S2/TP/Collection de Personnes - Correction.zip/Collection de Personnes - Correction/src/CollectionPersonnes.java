
import java.io.IOException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class CollectionPersonnes {
    private ArrayList<Personne> groupe;
    
    public CollectionPersonnes() throws IOException {
        LecteurFichier lf = new LecteurFichier();
        lf.choisirFichier("desPersonnes.txt");
        groupe = lf.lecture();
    }

    // A FAIRE PAR LES ETUDIANTS
    public void afficher() {
        for (Personne p : groupe) {
            p.afficher();
        }
    }

    // A FAIRE PAR LES ETUDIANTS
    public int effectifDeLAnnee(int annee){
        int effectif = 0;
        for(Personne p : groupe) {
            if(p.getAnneeNaiss() == annee) {
                effectif++;
            }
        }
        return effectif ;
    }
    
    // A FAIRE PAR LES ETUDIANTS
    public Personne laPlusProche(Personne autre){
        Personne tresProche = null;
        int proximiteMax = 0 ;
        for (Personne p : groupe) {
            if(!p.equals(autre)){
                int score = p.matchScore(autre) ;
                if(score>proximiteMax){
                    proximiteMax = score;
                    tresProche = p;
                }
            }
        }
        return tresProche;
    }
    
    // A FAIRE PAR LES ETUDIANTS
    public ArrayList<Personne> lesPlusProches(Personne autre){
        ArrayList<Personne> resultat = new ArrayList<Personne>();
        Personne pp = this.laPlusProche(autre);
        int proximiteMax = autre.matchScore(pp);
        for(Personne p : groupe){
            if(autre.getId()!=p.getId()){
                if(autre.matchScore(p) == proximiteMax) {
                    resultat.add(p);
                }
            }
        }
        return resultat;
    }
    
    // A FAIRE PAR LES ETUDIANTS
    public ArrayList<Personne> personnesGroupe(String g) {
        ArrayList<Personne> resultat = new ArrayList<Personne>();
        for(Personne p : groupe){
            if(p.getGroupe().equals(g)){
                resultat.add(p);
            }
        }
        return resultat;
    }
}
