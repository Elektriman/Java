import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author P. Rodriguez
 */
public class App {

    public static void main(String[] args) throws IOException {
        // A FAIRE PAR LES ETUDIANTS
        // II.A
        Personne marc = new Personne(1, "Dupond", "Marc", 'h', 1978, 
                "Surfeur", 3);
        Personne marie = new Personne(2, "Durand", "Marie", 'f', 1983, 
                "Bosseur", 2);
        
        System.out.println("Nom : " + marc.getNom() + ", Année : " 
                + marc.getAnneeNaiss() + ", Groupe : " + marc.getGroupe());
        System.out.println("Nom : " + marie.getNom() + ", Année : " 
                + marie.getAnneeNaiss() + ", Groupe : " + marie.getGroupe());
        
        marc.setGroupe("Bosseur");
        System.out.println("Nom : " + marc.getNom() + ", Année : " 
                + marc.getAnneeNaiss() + ", Groupe : " + marc.getGroupe());
        marc.afficher();
        
        // II.B
        System.out.println(marc);
        Personne marcbis = new Personne(1, "Dupond", "Marc", 'h', 1978, 
                "Surfeur", 3);
        System.out.println(marc == marcbis);
        System.out.println(marcbis);
        System.out.println(marc.equals(marcbis));
        
        // III.A
        CollectionPersonnes communaute = new CollectionPersonnes();
        communaute.afficher();

        int anneeTest = 1992 ;
        int nbPersDeLaMemeAnnee = communaute.effectifDeLAnnee(anneeTest);
        System.out.println("Il y a " + nbPersDeLaMemeAnnee 
                + " personnes nées en " + anneeTest);
        
        // III.B
        System.out.println("La proximité de Marc avec Marie est : " 
                + marc.matchScore(marie));
        
        // III.C
        Personne coupleMarc = communaute.laPlusProche(marc);
        System.out.println("La personne la plus proche de Marc est : ");
        System.out.println(coupleMarc);
        
        // III.D
        ArrayList<Personne> couplesMarie = communaute.lesPlusProches(marie);
        System.out.println("Les personnes les plus proches de Marie sont : ");
        
        // Syntaxe fonctionnelle compatible à partir de Java 8
        couplesMarie.forEach((p) -> System.out.println(p));
        
        // III.E
        ArrayList<Personne> lesSurfeurs = communaute.personnesGroupe("Surfeur");
        System.out.println("Les surfeurs sont : ");
        
        // Syntaxe fonctionnelle compatible à partir de Java 8
        lesSurfeurs.forEach((p) -> System.out.println(p));
    }
}
