/**
 *
 * @author P. Rodriguez
 */
public class Personne {

    // Définition des attributs d'une personne
    private int id;
    private String nom;
    private String prenom;
    private char genre;
    private int anneeNaiss;
    private String groupe;
    private int categorie;

    /**
     * Constructeur de personne.
     *
     * @param lid : identifiant de la personne
     * @param leNom : nom de famille
     * @param lePrenom : prénom
     * @param leGenre : 'h', 'f', ...
     * @param lAnnee : année de naissance
     * @param leGroupe : groupe "Bosseur", "Surfeur", ...
     * @param laCategorie : catégorie
     */
    Personne(int lid, String leNom, String lePrenom, char leGenre, int lAnnee, String leGroupe,  int laCategorie) {
        this.id = lid;
        this.nom = leNom;
        this.prenom = lePrenom;
        this.genre = leGenre;
        this.anneeNaiss = lAnnee;
        this.groupe = leGroupe;
        this.categorie = laCategorie;
    }

    /* Les getters */
    public int getId() {
        return this.id;
    }

    public String getNom() {
        return this.nom;
    }

    public String getPrenom() {
        return this.prenom;
    }

    public int getAnneeNaiss() {
        return this.anneeNaiss;
    }
    public String getGroupe() {
        return this.groupe;
    }
    public int getCategorie() {
        return this.categorie;
    }

    // A FAIRE PAR LES ETUDIANTS
    public boolean estHomme() {
        return this.genre == 'h';
    }

    // A FAIRE PAR LES ETUDIANTS
    public boolean estFemme() {
        return this.genre == 'f';
    }

    /* Les setters */
    public void setGroupe(String leGroupe) {
        this.groupe = leGroupe;
    }
    public void setCategorie(int laCategorie) {
        this.categorie = laCategorie;
    }
    
    /* Affichage */
    public void afficher() {
        String naissance = "né en ";
        if(this.estFemme()) {
            naissance = "née en ";
        }
	System.out.println(this.prenom + " " + this.nom + ", " + naissance
                + this.anneeNaiss + ", " + this.groupe + " de catégorie "
                + this.categorie);
    }
    
    // A FAIRE PAR LES ETUDIANTS
    public String toString() {
        String naissance = "né en ";
        if(this.estFemme()) {
            naissance = "née en ";
        }
        return this.prenom + " " + this.nom + ", " + naissance 
                + this.anneeNaiss + ", " + this.groupe 
                + " de catégorie " + this.categorie;
    }

    // A FAIRE PAR LES ETUDIANTS
    public boolean equals(Object p) {
        if (p.getClass() == this.getClass()) {
            Personne aux = (Personne) p;
            return (aux.getId() == this.getId());
        } else {
            return false;
        }
    }
    
    // A FAIRE PAR LES ETUDIANTS
    public int matchScore(Personne autre) {
        int score = 0;
        // Appartenance au même groupe
        if(this.getGroupe().equals(autre.getGroupe())) {
            score += 3;
        }
        
        // Proximité de catégorie
        int gainCategorie;
        switch(Math.abs(this.getCategorie()-autre.getCategorie())) {
            case 0 : 
                gainCategorie = 4; 
                break;
            case 1 : 
                gainCategorie = 2; 
                break;
            case 2 :
                gainCategorie = 0;
                break;
            default :
                gainCategorie = 0;
        }
        score += gainCategorie;
        
        // Différence d'âge
        int differenceAge = Math.abs(this.getAnneeNaiss() - autre.getAnneeNaiss());
        int gainAge = 4 - differenceAge / 3;
        score += gainAge;
        return score;
    }
}
