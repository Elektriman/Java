import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author P. Rodriguez
 */
public class App {
   
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // Déclaration d'un lecteur de fichiers
        LecteurFichier monLecteur;
        // Création du lecteur
	monLecteur = new LecteurFichier() ; 	
        // Choix du fichier manipulé par le lecteur
	monLecteur.choisirFichier("revenus.txt") ;

        ArrayList<Double> revenus; // Déclaration d'un arraylist pour récupérer les salaires.
	revenus = monLecteur.lectureReels(); // Lecture des noms dans le fichier et stockage dans le tableau
	// Vérification du nombre de revenus lus : 46.
        System.out.println(revenus.size());

        // Début calculs à afficher :
        
        // Construction du gestionnaire
        GestionSalaires gs = new GestionSalaires(revenus);
        // Construction de la collection de résutalts.
        ArrayList<String> resultats = new ArrayList<String>();
        
        // Salaire minimum
        String calcul = "Salaire minimum : " + gs.min();
        System.out.println(calcul);
        resultats.add(calcul);
        
        // Salaire maximum
        calcul = "Salaire maximum : " + gs.max();
        System.out.println(calcul);
        resultats.add(calcul);

        // Effectifs
        calcul = "Nombre total de salaires : " + gs.nombreTotal();
        System.out.println(calcul);
        resultats.add(calcul);
        
        // Salaire moyen
        calcul = "Salaire moyen : " + gs.moyenne();
        System.out.println(calcul);
        resultats.add(calcul);
        
        // Salaire median (faux)
        calcul = "Salaire median (faux) : " + gs.medianeFAUX();
        System.out.println(calcul);
        resultats.add(calcul);
        
        // Salaire median (vrai)
        calcul = "Salaire median : " + gs.mediane();
        System.out.println(calcul);
        resultats.add(calcul);
        
        // Répartition des salaires par classes.
        int nbClasses = 5;
        double sommePourc = 0; // à la fin, on doit retrouver 100%
        calcul = "Répartition sur "+ nbClasses + " classes : ";
	System.out.println(calcul);
        resultats.add(calcul);
        
        int effClasse; // Effectif de la classe courante
        double r; // Borne inférieure de la classe courante
        // Longueur d'une classe
        double longueur = (gs.max() - gs.min()) / nbClasses;
        for(int i = 0;  i < nbClasses; i++) {
            r  = gs.min() + i * longueur;
            // Seule la dernière classe a la borne supérieure incluse
            boolean dernier = (i == nbClasses-1);
            effClasse = gs.effectifIntervalle(r, r + longueur, dernier);
            double proportion = ((double) effClasse) / gs.nombreTotal();
            sommePourc += proportion;
            // "\t" génère une tabulation
            calcul = "\t" + effClasse + " Salaires entre " + r + " et " 
                    + (r + longueur) + "(" + (100 * proportion) + "%)";
            System.out.println(calcul);
            resultats.add(calcul);
	} // Ce serait mieux de n'appeler gs.min() qu'une seule fois.
        calcul = "Total : " + (sommePourc * 100) + "%";
	System.out.println(calcul);
        resultats.add(calcul);

        resultats.add("");
	EnregistreurFichier monEF; // Déclaration d'un Enregistreur de fichiers
	monEF = new EnregistreurFichier();
	monEF.choisirFichier("resultats.txt");
	monEF.enregistrerArrayList(resultats);
    }
}