
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Classe permettant la gestion des salaires.
 * 
 * @author jviaud
 */
public class GestionSalaires {
    /**
     * Collection des salaires à gérer.
     */
    private ArrayList<Double> salaires;

    /**
     * Constructeur du gestionnaire avec une collection vide.
     *
     * Ne sera pas utilisé dans ce TP
     */
    public GestionSalaires() {
        this.salaires = new ArrayList<>();
    }

    /**
     * Constructeur du gestionnaire avec une collection existante.
     *
     * @param salaires : les salaires à traiter.
     */
    public GestionSalaires(ArrayList<Double> salaires) {
        this.salaires = salaires;
    }
    
    /**
     * Calcul du salaire minimum.
     * 
     * ATTENTION : la collection est supposée non vide.
     * 
     * @return : le salaire minimum 
     */
    public Double min() {
	Double m = this.salaires.get(0);
        // Syntaxe "for classique"
	for (int i = 0; i < this.salaires.size(); i++) {
		if (this.salaires.get(i) < m) {
                    m = this.salaires.get(i);
                }
	}
	return m;
    }

    /**
     * Calcul du salaire maximum.
     * 
     * ATTENTION : la collection est supposée non vide.
     * 
     * @return : le salaire maximum 
     */
    public Double max() {
	Double m = this.salaires.get(0);
	for (Double d : this.salaires) {
		if (d > m) {
                    m = d;
                }
	}
	return m;
    }

    /**
     * Taille de la collection.
     * 
     * @return : nombre de salaires
     */
    public Integer nombreTotal() {
        return this.salaires.size();
    }

    /**
     * Moyenne de la collection.
     * 
     * @return : moyenne des salaires
     */
    public Double moyenne() {
	Double somme = 0.0;
        for (Double d : this.salaires) {
               somme += d;
        }
	return somme/this.nombreTotal();
    }
    
    /**
     * Moyenne du min et du max.
     *
     * @return moyenne entre min et max
     */
    public Double medianeFAUX() {
        return (this.max()-this.min())/2;
    }

    /**
     * Salaire médian.
     * Dans une collection TRIEE :
     * + Si la collection est de taille 2n+1, la médiane est la n-ième valeur
     * + Si la collection est de taille 2n, la médiane est la moyenne de
     * la n-ième valeur et de la suivante.
     * 
     * @return le salaire médian
     */
    public Double mediane() {
        Double med;
        ArrayList<Double> salaireTri = this.tri();
        if (this.nombreTotal() % 2 == 0) {
            med = (salaireTri.get((this.nombreTotal() / 2) - 1) 
                    + salaireTri.get((this.nombreTotal() / 2))) / 2;
        } else {
            med = salaireTri.get((this.nombreTotal() / 2));
        }
        return med;
    }

    /**
     * Tri les salaires.
     * Tri par sélection.
     *
     * @return les salaires triés
     */
    private ArrayList<Double> tri() {
        // Recopie des salaires pour ne pas modifier this.salaires.
        ArrayList<Double> tmp = (ArrayList<Double>) this.salaires.clone();
        ArrayList<Double> res = new ArrayList<>();
        while (!tmp.isEmpty()) {
            // Recherche du min
            Double m = tmp.get(0); // Valeur du min
            int pos = 0; // Position du min
            // Syntaxe "for classique"
            for (int i = 0; i < tmp.size(); i++) {
		if (tmp.get(i) < m) {
                    m = tmp.get(i);
                    pos = i;
                }
            }
            res.add(m); // Ajout à la fin du min au résultat
            tmp.remove(pos); // Suppression du min de la collection
        }
        return res;
    }

    /**
     * Effectif de la collection dans l'intervalle.
     * 
     * @param min : borne inférieure de l'intervalle
     * @param max : borne supérieure de l'intervalle
     * @param maxInclus : vrai si max est inclus dans l'intervalle
     * @return le nombre de valeurs dans l'intervalle
     */
    public int effectifIntervalle(double min, double max, boolean maxInclus){
	int n = 0;
	for (int i = 0; i < this.nombreTotal(); i++) {
		if ( this.salaires.get(i) >= min && 
                        (this.salaires.get(i) < max || 
                        this.salaires.get(i) == max && maxInclus) ) {
                    n++;
                }
	}
	return n;
    }
}
