import java.io.IOException;

/**
 *
 * @author P. Rodriguez
 */
public class App {

    public static void main(String[] args) throws IOException {
        
    }
}
