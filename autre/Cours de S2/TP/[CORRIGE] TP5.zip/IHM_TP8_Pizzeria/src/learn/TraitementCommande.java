package learn;

import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class TraitementCommande {

    private ArrayList<LigneDeCommande> lesLignesCommande;
    
    
    public TraitementCommande() {
       try{ 
        this.lesLignesCommande = lectureFichier("lignesDeCommande.txt") ;
       }
       catch(IOException e){ System.out.println("ERREUR CHARGEMENT"); };
        
    }
    	
	public ArrayList<LigneDeCommande> lignesCommandeSansLaCommande(int n)
	{
		ArrayList<LigneDeCommande> resultat = new ArrayList() ;
		for(LigneDeCommande li : this.lesLignesCommande)
			if(li.getNumCommande()!=n) 
				resultat.add(li) ;
		return resultat ;
	}

	
	public ArrayList<LigneDeCommande> lignesCommandeDeLaCommande(int n)
	{
		ArrayList<LigneDeCommande> resultat = new ArrayList() ;
		for(LigneDeCommande li : this.lesLignesCommande)
			if(li.getNumCommande()==n) 
				resultat.add(li) ;
		return resultat ;
	}
	
	public void afficherCommandes()
	{
		ArrayList<Integer> numsC = listeNumerosCommande() ;
		for(Integer numCommande : numsC)
		
			afficherLaCommande(numCommande);
	}
	
	public void afficherLaCommande(int numC)
	{
		double somme = 0 ;
		String affDebut ="Commande n°"+numC + " : " ;
		String affFin = "" ;
		for(LigneDeCommande li : this.lesLignesCommande)
		{	
			if(li.getNumCommande()==numC) 
			{	
				affFin+="\n\t"+li ;
				somme+=li.getPrix() ;
			}
		}
		DecimalFormat df = new DecimalFormat("##.00€ ") ;
		System.out.println(affDebut + df.format(somme) + affFin) ;
	}
	
        
        public  ArrayList<Integer> listeNumerosCommande()
	{
		ArrayList<Integer> resultat = new ArrayList() ;
		int iRes = 0 ;
		for(LigneDeCommande li : this.lesLignesCommande)
			if(!resultat.contains(li.getNumCommande()))
				resultat.add(li.getNumCommande()) ;
		return resultat ;
	}
	
	
	public double prixTotal()
	{
		double resultat = 0 ;
		for(LigneDeCommande li : this.lesLignesCommande)	
			resultat += li.getPrix() ;
		return resultat ;
	}
	
	public double prixTotalDeLaCommande(int numCommande)
	{
		double resultat = 0 ;
		for(LigneDeCommande li : this.lesLignesCommande)	
			if(li.getNumCommande()==numCommande) resultat += li.getPrix() ;
		return resultat ;
	}

	
	public void afficher()
	{
		for(Object li : this.lesLignesCommande)	System.out.println(li) ;
	}
        
        public void afficher(ArrayList<LigneDeCommande> desLignes)
	{
		for(LigneDeCommande li : desLignes)	System.out.println(li) ;
	}
        
	
	public ArrayList<LigneDeCommande> lectureFichier(String nomFichier) throws IOException
	{
		ArrayList<LigneDeCommande> resultat ;
		resultat = new ArrayList() ;
		
		FileReader fr = new FileReader(nomFichier) ;
		
		LigneDeCommande li = new LigneDeCommande() ;
		while(li.lireDansFichier(fr))
		{
				resultat.add(li) ;
				li = new LigneDeCommande() ;	
		}
		return resultat ;
	}
        
        
        public String formater(double nombre){
            Locale france = new Locale("fr", "FR", "EURO");
            Locale.setDefault(france);
            NumberFormat nf = NumberFormat.getCurrencyInstance() ;
            return nf.format(nombre) ;
        }

    
}
