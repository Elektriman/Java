/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package learn;

import java.util.ArrayList;

/**
 *
 * @author csempe
 */
public class App {
    public static void main(String[] arg ){
        
                TraitementCommande tc = new TraitementCommande();
                tc.afficher();
                
		double prixTotal = tc.prixTotal() ;
		System.out.println("Prix total : "+ prixTotal + "€") ;
                
		double prixTotalCommande3 = tc.prixTotalDeLaCommande(3) ;
		System.out.println("Prix total de la commande 3 : "+ prixTotalCommande3 + "€") ;
		ArrayList <Integer> numC = tc.listeNumerosCommande() ;
                
		for (Integer val : numC) {
                    System.out.println(val);            
                }
                

		tc.afficherCommandes() ; 
                ArrayList<LigneDeCommande> resultat;
		tc.afficher(tc.lignesCommandeDeLaCommande(5)) ;
		System.out.println("Sans la commande n°5 ");
		tc.afficher(tc.lignesCommandeSansLaCommande(5)) ;
    }
}
