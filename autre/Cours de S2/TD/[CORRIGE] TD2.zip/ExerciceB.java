import java.util.Scanner;

public class ExerciceB {

  public static void main(String[] args) {
    Scanner ecouteur = new Scanner(System.in);
    System.out.print("Entrez un entier : ");
    int entier = ecouteur.nextInt();
    System.out.println("Voici la table de multiplication de " + entier + " : ");
    for (int i = 1; i <= 10; i++) {
      System.out.println(entier + " fois " + i + " = " + (entier*i));
    }
  }
}
