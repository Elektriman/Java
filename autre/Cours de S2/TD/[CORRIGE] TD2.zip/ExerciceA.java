import java.util.Scanner;

public class ExerciceA {

  public static void main(String[] args) {
    double a = 10.5 ;
    int b = 4 ;
    double s = 0 ;
    for(int u = 1 ; u<=b ; u++){
      s = s + a ;
    }
    System.out.println("Résultat : " + s) ;
  }
}
