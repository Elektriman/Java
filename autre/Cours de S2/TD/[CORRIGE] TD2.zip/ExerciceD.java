import java.util.Scanner;

public class ExerciceD {
  public static int U(int n) {
    int resultat = 2; // Initialisation à U_0 = 2
    for (int i = 0; i < n; i++) { // A méditer !
      resultat = 3*resultat - 25;
    }
    return resultat;
  }

  public static int S(int n) {
    int somme = 0;
    for (int i = 0; i < n + 1; i++) {
      somme = somme + U(i);
    }
    return somme;
  }

  public static int Sv2(int n) {
    /* Calcul conjoint de S et U 
     * pour éviter les répétitions
     */
    int U = 2;
    int somme = 0;
    for (int i = 0; i < n + 1; i++) {
      somme = somme + U;
      U = 3 * U - 25;
    }
    return somme;
  }

  public static void main(String[] args) {
    // Test-Appel de U
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    System.out.println(U(a));

    // Test-Appel de S et Sv2
    int b = sc.nextInt();
    System.out.println(S(b));
    System.out.println(Sv2(b));
  }
}
