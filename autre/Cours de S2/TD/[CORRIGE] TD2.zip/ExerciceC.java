import java.util.Scanner;

public class ExerciceC {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Entrez un entier : ");
    int n = sc.nextInt();
    String s = "";
    while (!(n==0)) {
      if (n%2==0) {
        s = "0" + s;
      } else {
        s = "1" + s;
      }
      n = n/2;
    }
    System.out.println(s);
  }
}
