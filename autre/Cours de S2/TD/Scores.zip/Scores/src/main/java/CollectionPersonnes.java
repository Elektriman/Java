
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class CollectionPersonnes {
    
    public ArrayList<Personne> groupe;

    public CollectionPersonnes() {
        /* 
         * Opérateur "diamond" : à partir de Java 7
         * Ajouter Personne entre les chevrons donne un code compatible Java 6
         */
        groupe = new ArrayList<>();
    }
    
    public void afficherPersonnes() {
        /*
         * Version 1 : 
         * for "classique"
         * toString explicite
        for (int i = 0; i < groupe.size(); i++) {
        System.out.println(groupe.get(i).toString());
         */
        /* Version 2 :
         * for "each"
         * toString implicite
         */
        for (Personne p : groupe) {
            System.out.println(p);
        }
        /* Version 3 :
         * Opérateur -> à partir de Java 8
         * Voir cours de L3 "Programmation Fonctionnelle"
        groupe.forEach((p) -> {
            System.out.println(p);
        });
         */
    }
    
    public Personne personneDeNumero(int num) {
        Personne p = null; // Si on ne trouve pas la personne
        if (!groupe.isEmpty()) {
            int i = 0;
            /* Tant que :
             * On est dans la collection
             * et que le nom n'est pas bon
             */
            while ((i < groupe.size()) && !(groupe.get(i).getNumero() == num)) {
                i++;
            }
            if (i < groupe.size()) {
                // On est sorti de la boucle car la personne est trouvée
                p = groupe.get(i);
            }
        }
        return p;
    }
    
    public Personne personneDeNom(String s) {
        Personne p = null; // Si on ne trouve pas la personne
        if (!groupe.isEmpty()) {
            int i = 0;
            /* Tant que :
             * On est dans la collection
             * et que le nom n'est pas bon
             */
            while ((i < groupe.size()) && !groupe.get(i).getNom().equals(s)) {
                i++;
            }
            if (i < groupe.size()) {
                // On est sorti de la boucle car la personne est trouvée
                p = groupe.get(i);
            }
        }
        return p;
    }
}
