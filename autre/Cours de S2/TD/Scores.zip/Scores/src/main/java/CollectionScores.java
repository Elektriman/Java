
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class CollectionScores {
    
    public ArrayList<Score> scores;

    public CollectionScores() {
        scores = new ArrayList<>();
    }

    public Score meilleurScore() {
        Score res = null; 
        for (Score s : scores) {
            /* La seconde moitié du OU n'est pas executée 
             * si la première est vraie 
             */
            if (res == null || res.getResultat() < s.getResultat()) {
                res = s;
            }
        }
        return res;
    }

    public int meilleurJoueur() {
        int res = 0; 
        for (Score s : scores) {
            /* La seconde moitié du OU n'est pas executée 
             * si la première est vraie 
             */
            if (res == 0 || res < s.getResultat()) {
                res = s.getNumero();
            }
        }
        return res;
    }
    
    public CollectionScores scoresDuJoueur(int num) {
        CollectionScores res = new CollectionScores();
        for (Score s : scores) {
            if (s.getNumero() == num) {
                res.scores.add(s);
            }
        }
        return res;
    }
    
    public double scoreMoyenDuJoueur(int num) {
        double somme = 0.0;
        int nbScores = 0;
        for (Score s : scores) {
            if (s.getNumero() == num) {
                nbScores++;
                somme += s.getResultat();
            }
        }
        return somme / nbScores;
    }
}
