/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class GestionScores {
    CollectionPersonnes collecJoueur;
    CollectionScores collecScores;
    
    public GestionScores() {
        this.collecJoueur = new CollectionPersonnes();
        this.collecScores = new CollectionScores();
    }
    
    public void afficherScores() {
        for (Score s : collecScores.scores) {
            Personne p = collecJoueur.personneDeNumero(s.getNumero());
            System.out.println(p.getPrenom() + " " + p.getNom() + " "
                    + "a obtenu " + s.getResultat() + " points");
        }
    }

    public CollectionScores scoresMoyens() {
        CollectionScores colSco = new CollectionScores();
        /*
         * Un joueur peut avoir joué plusieurs fois et
         * peut apparaitre plusieurs fois dans collecScores mais
         * chaque joueur n'apparait qu'une seul fois dans collecJoueur
         * c'est donc cette collection qui va être parcourue.
         */
        for (Personne j : collecJoueur.groupe) {
            double moyenne = collecScores.scoreMoyenDuJoueur(j.getNumero());
            Score sc = new Score(j.getNumero(),moyenne);
            colSco.scores.add(sc);
        }
        return colSco;
    }
}
