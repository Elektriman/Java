/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class AppScores {
    
    public static void main(String[] args) {
        Personne georges = new Personne(1, "Windsor", "Georges");
        Personne charlotte = new Personne(2, "Bourbon", "Louis");
        
        CollectionPersonnes communaute = new CollectionPersonnes();
        communaute.groupe.add(georges);
        communaute.groupe.add(charlotte);
        
        System.out.println("=== COLLECTION COMPLETE ===");
        communaute.afficherPersonnes();
        
        System.out.println("=== RECHERCHE PAR LE NUMERO ===");
        System.out.println(communaute.personneDeNumero(1));
        
        System.out.println("=== RECHERCHE PAR LE NOM ===");
        System.out.println(communaute.personneDeNom("Bourbon"));
        
        Score score1 = new Score(1, 1024);
        Score score2 = new Score(1, 2048);
        
        CollectionScores collecSc = new CollectionScores();
        collecSc.scores.add(score1);
        collecSc.scores.add(score2);

        System.out.println("Le meilleur score est : ");
        System.out.println(collecSc.meilleurScore());
        System.out.println(collecSc.meilleurJoueur());
        System.out.println(collecSc.scoreMoyenDuJoueur(1));
        
        Score score3 = new Score(2, 4096);
        
        System.out.println("=== TEST afficherScores ===");
        GestionScores gs = new GestionScores();
        gs.collecJoueur.groupe.add(georges);
        gs.collecJoueur.groupe.add(charlotte);
        gs.collecScores.scores.add(score1);
        gs.collecScores.scores.add(score2);
        gs.collecScores.scores.add(score3);
        
        
        System.out.println("=== TEST scoresMoyens ===");
        gs.afficherScores();
        for (Score s : gs.scoresMoyens().scores) {
            System.out.println(s);
        }
    }
}
