/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class Score {
    private int numero;
    private double resultat;

    public Score(int numero, double resultat) {
        this.numero = numero;
        this.resultat = resultat;
    }

    public int getNumero() {
        return numero;
    }

    public double getResultat() {
        return resultat;
    }
    
    public String toString() {
        return "Numéro : " + numero + " -> Score : " + resultat;
    }
    
}
