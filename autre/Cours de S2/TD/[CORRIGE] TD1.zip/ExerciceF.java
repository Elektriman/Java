import java.util.Scanner;

public class ExerciceF {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    System.out.println("Initialisation");
    System.out.print(" Entrez le stock de produit disponible : ");
    int stock = s.nextInt();
    System.out.println("Consommantion");
    int conso;
    while (stock > 0) {
      System.out.print(" Combien de produit voulez-vous ? ");
      conso = s.nextInt();
      if (conso > stock) {
        System.out.println("Impossible : Il reste " + stock +
                            " unités de produit");
      } else {
        stock = stock - conso;
        // stock -= conso; // Autre syntaxe
        System.out.println("Il reste " + stock + " unités de produit");
      }
    }
    System.out.println("Fin");
  }
}
