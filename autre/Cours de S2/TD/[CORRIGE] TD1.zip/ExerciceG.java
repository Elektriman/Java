import java.util.Scanner;

public class ExerciceG {
  public static void main(String[] args) {
    int total = 1000;
    Scanner ecouteur = new Scanner(System.in);
    int cagnotte = 0;
    int participation;
    int nbPers = 0;
    while (cagnotte < total) {
      System.out.print("Combien voulez-vous donner ?");
      participation = ecouteur.nextInt();
      cagnotte += participation;
      nbPers ++;
    }
    System.out.println(nbPers + " personnes ont participé");
    System.out.println("Participation moyenne : " + (cagnotte / (1.0 * nbPers)));
  }
}
