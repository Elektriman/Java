public class ExerciceE {
  public static void main(String[] args) {
    int a = 20;
    int b = 6;
    int n = 0;
    while (a > b) {
      a = a - b;
      n++;
    }
    System.out.println("Résultat : " + a + n);
  }
}
