import java.util.Scanner;

public class ExerciceD {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int annee = s.nextInt();
    if ( ((annee % 4 == 0) && (annee % 100 != 0))
        || (annee % 400 == 0) ) {
      System.out.println("Bissextile");
    } else {
      System.out.println("Non bissextile");
    }
  }
}
