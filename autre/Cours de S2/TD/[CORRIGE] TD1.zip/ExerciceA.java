public class ExerciceA {
  public static void main(String[] args) {
    int n;
    double x;
    x = 8 + 6 / 4;
    n = 5;
    x = n * x;
    System.out.println("Résultat : " + x);
  }
}
