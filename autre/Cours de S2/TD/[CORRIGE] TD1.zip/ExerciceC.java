import java.util.Scanner;

public class ExerciceC {
  public static void main(String[] args) {
    Scanner ecouteur = new Scanner(System.in);
    double degre = ecouteur.nextDouble();
    double radian = degre / 180.0 * Math.PI;
    System.out.println("La mesure en radian est : " + radian);
  }
}
