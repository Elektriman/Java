import java.util.Scanner;

public class ExerciceB {
  public static void main(String[] args) {
    Scanner ecouteur;
    ecouteur = new Scanner(System.in);
    double x;
    x = ecouteur.nextInt();
    int n;
    n = ecouteur.nextInt();
    if (n > x) {
      System.out.println(x + n);
    } else {
      System.out.println("Le résultat est " + x + n);
    }
  }
}
