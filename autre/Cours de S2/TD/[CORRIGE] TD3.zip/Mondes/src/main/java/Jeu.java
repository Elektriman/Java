/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jviaud
 */
public class Jeu {
    public static void main(String[] args) {
        Partie p = new Partie();
        p.jouer();

        double moyenne = p.simuler(1000);
        System.out.println("Partie terminée en moyenne en " + moyenne + " coups");
    }
}

class Joueur {
/* Les différents états : 
 * Un joueur peut se trouver dans le monde 0, le monde 1 ... ou le monde 4.
 * Les différents états sont donc :
 *  - monde0 (dans le programme, on le représentera par la valeur 0 dans la variable monde.
 *  - monde1
 *  - monde2
 *  - monde3
 *  - monde4
 * Les changements de monde :  
 *  - score < 6 (stagnation), 
 *  - score dans [6;8] (on suit le trajet long), 
 *  - score > 8 (on suit un trajet court).
 *
 * Table des transitions (monde suivant en fonction du monde actuel et du score)
 * Monde \ Score |  score < 6 | 6 <= score <= 8 | score > 8
 * --------------------------------------------------------
 * monde 0       |  monde 0   |  monde 1        |  monde 2
 * monde 1       |  monde 1   |  monde 2        |  monde 3
 * monde 2       |  monde 2   |  monde 1        |  monde 3
 * monde 3       |  monde 3   |  monde 1        |  monde 4
 */
    public final static int MONDE_FINAL = 4;
    public final static int MONDE_INITIAL = 0;
    private int MondeCourant;
    
    public Joueur() {
        this.MondeCourant = MONDE_INITIAL;
    }

    public int getMondeCourant() {
        return MondeCourant;
    }

    public void setMondeCourant(int MondeCourant) {
        this.MondeCourant = MondeCourant;
    }

    public boolean gagne() {
        return this.MondeCourant == MONDE_FINAL;
    }

    public int mondeSuivant(int mondeActuel, int score) {
        int nouveauMonde;
        if (score < 6) {
            nouveauMonde = mondeActuel;
        } else {
            switch (mondeActuel) {
                case 0 : 
                    if (score <= 8) {
                        nouveauMonde = 1;
                    } else {
                        nouveauMonde = 2;
                    }
                break;
                case 1 : 
                    if (score <= 8) {
                        nouveauMonde = 2;
                    } else {
                        nouveauMonde = 3;
                    }
                    break;
                case 2 : if (score <= 8) {
                    nouveauMonde = 1;
                } else {
                    nouveauMonde = 3;
                }
                break;
                case 3 : 
                    if (score <= 8) {
                        nouveauMonde = 1;
                    } else {
                        nouveauMonde = MONDE_FINAL;
                    }
                    break;
                default : 
                    nouveauMonde = MONDE_INITIAL;
			}
		}// Fin du else
        return nouveauMonde;
    }
}

class Partie {
    Joueur jean;

    public Partie() {
        this.jean = new Joueur();
    }

    public int jouer() {
        int nbCoups = 0 ;
        String verbe;
        while (!this.jean.gagne()) {
            int score = unLancer() + unLancer();
            int mondeSuivant = this.jean.mondeSuivant(this.jean.getMondeCourant(), score);
            if (this.jean.getMondeCourant() == mondeSuivant) {
                verbe = "reste";
            } else {
                verbe = "passe";
            }
            //System.out.println("Score de " + score + ": je "
            //        + verbe + " dans le monde " + mondeSuivant);
            this.jean.setMondeCourant(mondeSuivant);
            nbCoups++;
        }
        return nbCoups;
    }

    public double simuler(int n) {
        double nTotal = 0.0;
        for(int i = 0; i < n; i++) {
            this.jean.setMondeCourant(Joueur.MONDE_INITIAL);
            nTotal += this.jouer();
        }
        return nTotal / n;
    }

    private int unLancer() {
        return (int) (6*Math.random() + 1 );
    }
}