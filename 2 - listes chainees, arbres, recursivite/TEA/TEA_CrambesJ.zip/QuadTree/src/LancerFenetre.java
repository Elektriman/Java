

class LancerFenetre
{
	
 
 public static void main(String args[])
 {
 	Fenetre maFenetre = new Fenetre("QuadTrees", 800, 800); 
 	
 }
 
}